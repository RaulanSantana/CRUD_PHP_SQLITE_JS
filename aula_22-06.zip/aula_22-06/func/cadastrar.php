<?php 
session_start();
include_once('conexao.php');
if(isset($_POST['enviar'])){
    $nome = $_POST['nome'];
    $email= $_POST['email'];
    $senha= password_hash($_POST['senha'],PASSWORD_DEFAULT);

    if(filter_var($email,FILTER_VALIDATE_EMAIL)){
        $query="select email from usuarios where email=:e";
        $stmt = $conexao->prepare($query);
        $stmt->bindParam(':e',$email);
        $stmt->execute();
        $rows= $stmt->fetch(PDO::FETCH_ASSOC);
        if($rows){ 
            $_SESSION['mensagem']= "Email ja existe";
            header('Location: ../cadastro.php');
        exit;
       
      
       } else {
        $query="INSERT INTO usuarios(nome,email,senha) values (:n,:e,:s)";
        $stmt = $conexao->prepare($query);
        $stmt->bindParam(':n',$nome);
        $stmt->bindParam(':s',$senha);
        $stmt->bindParam(':e',$email);
        try{
        $stmt->execute();
        $_SESSION['mensagem']= "Cadastro realizado com sucesso.";
        header('Location: ../login.php');
        }catch  (PDOException $e){
            $_SESSION['mensagem']="Error ao cadastrar";
            header('Location: ../cadastro.php');
        }
       }
    } else {
        $_SESSION = "Tipo de email invalido";
        header('Location: ../cadastro.php');
    }

   

   

 
}
?>