<?php 
include_once ('conexao.php');
$id= $_GET['id'];
$query="Delete from usuarios where id=:id";
$stmt = $conexao->prepare($query);
$stmt-> bindParam(':id',$id);
$stmt->execute();
header('Location: ../index.php');
exit;
?>