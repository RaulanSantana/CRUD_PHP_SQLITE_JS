<?php
session_start();
include_once('conexao.php');

if (isset($_POST['enviar'])) {
    $id = $_POST['id'];
    $nome = $_POST['nome'];   
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
    $email = $_POST['email'];

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        try {
         
            $query = "SELECT email FROM usuarios WHERE email = :email AND id != :id";
            $stmt = $conexao->prepare($query);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            $rows = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($rows) {
                $_SESSION['mensagem'] = "Email já está em uso por outro usuário";
                header("Location: ../editarform.php?id={$id}&nome={$nome}&email={$email}");
                exit;
            } else {
              
                $query = "UPDATE usuarios SET nome = :nome, email = :email, senha = :senha WHERE id = :id";
                $stmt = $conexao->prepare($query);
                $stmt->bindParam(':id', $id);
                $stmt->bindParam(':nome', $nome);
                $stmt->bindParam(':senha', $senha);
                $stmt->bindParam(':email', $email);
                $stmt->execute();
                $_SESSION['mensagem'] = "Editado com sucesso";
                header("Location: ../index.php");
                exit;
            }
        } catch (PDOException $e) {
            $_SESSION['mensagem'] = "Erro ao editar: " . $e->getMessage();
            header("Location: ../editarform.php?id={$id}&nome={$nome}&email={$email}");
            exit;
        }
    } else {
        $_SESSION['mensagem'] = "Tipo de email inválido";
        header("Location: ../editarform.php?id={$id}&nome={$nome}&email={$email}");
        exit;
    }
}
?>
