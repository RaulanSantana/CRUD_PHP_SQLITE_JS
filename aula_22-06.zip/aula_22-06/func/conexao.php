<?php 
$conexao = new PDO('sqlite:' . __DIR__ . '/usuarios.db');


?>