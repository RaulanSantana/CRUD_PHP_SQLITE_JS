<?php 
session_start();
include_once('conexao.php');

if (isset($_POST['submit'])) {

    $email = $_POST['email'];
    $senha = $_POST['senha'];

    if(filter_var($email, FILTER_VALIDATE_EMAIL)){
        $query ="SELECT * FROM usuarios WHERE email=:email";
        $stmt = $conexao->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $rows = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if($rows){
            $emailvalido = $rows['email'];
            $idvalido = $rows['id'];
            $senhavalia = $rows['senha'];
            $nomevalido = $rows['nome'];
            
            if(password_verify($senha, $senhavalia)){
                $_SESSION['id'] = $idvalido;
                $_SESSION['nome'] = $nomevalido;
                $_SESSION['email'] = $emailvalido;
                header('Location: ../index.php');
                exit;
            } else {
                $_SESSION['mensagem'] = "Senha inválida";
                header('Location: ../login.php');
                exit;
            }
        } else {
            $_SESSION['mensagem'] = "Email não encontrado";
            header('Location: ../login.php');
            exit;
        }
    } else {
        $_SESSION['mensagem'] = "Email inválido";
        header('Location: ../login.php');
        exit;
    }
}
?>
