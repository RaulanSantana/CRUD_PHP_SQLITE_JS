<?php 
session_start();
$mensagem = isset($_SESSION['mensagem']) ? $_SESSION['mensagem'] : "";
unset($_SESSION['mensagem']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
       
        <div class="text-right mb-3">
            <a href="cadastro.php" class="btn btn-success">Cadastrar</a>
        </div>
        
        <form action="func/autenticar.php" method="post">
            <fieldset class="border p-4">
                <legend class="w-auto">Login</legend>
                <div class="form-group">
                    <label for="nome">Email:</label>
                    <input type="text" name="email" class="form-control">
                </div>
                <div class="form-group">
                    <label for="senha">Senha:</label>
                    <input type="password" name="senha" class="form-control">
                </div>
                <button  type="submit" name="submit" class="btn btn-primary">Logar</button>
            </fieldset>
        </form>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <?php if($mensagem): ?>
<div class="modal fade" id="modalAviso" tabindex="-1" role="dialog" aria-labelledby="modalAvisoLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">  
            <h5 class="modal-title" id="modalAvisoLabel">Aviso</h5>        
            </div>
            <div class="modal-body">
                <p><?php echo $mensagem;?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
            </div>
        </div>
</div>

    <!--funcao em java script para pegar a mensagem e exibir automaticamente quando houver-->
<script>  
        $(document).ready(function() {
            $('#modalAviso').modal('show');
        });
    </script>
<?php endif;?>
</body>





</html>
