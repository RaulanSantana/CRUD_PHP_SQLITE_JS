<?php 
session_start();
if(!isset($_SESSION['id']) && !isset($_SESSION['email'])){
    header('Location: ../login.php');
}

$mensagem = isset($_SESSION['mensagem']) ? $_SESSION['mensagem'] : "";
unset($_SESSION['mensagem']);

$nome= $_SESSION['nome'];
include_once('func/conexao.php');



$query="select * from usuarios";
$stmt = $conexao->prepare($query);
$stmt->execute();
$result= $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <title>Document</title>
</head>
<header class="bg-dark text-white py-3">
        <div class="container">
            <div class="row">
                <div class="col">
                 
                    <p class="mb-0">Bem-vindo <?php echo ucwords($nome); ?></p>
                </div>
            </div>
            <div class="row">
                <div class="col">
                   <a href="func/logout.php">Sair</a>
                </div>
            </div>
        </div>
    </header>
<body>
 
    <div class="container mt-5">
        <fieldset class="border p-4">
        <legend class="w-auto">Usuarios cadastrados</legend>
            <?php 
                echo "<table class='table table-striped'>";
                echo "<thead><tr><th>Id</th><th>Nome</th><th>Email</th><th>CRUD</th></tr></thead><tbody>";
                foreach($result as $res){
                    echo "<tr>";
                    echo "<td>{$res['id']}</td>";
                    echo "<td>{$res['nome']}</td>";
                    echo "<td>{$res['email']}</td>";
                    echo "<td>
                    <a href='func/deletar.php?id={$res['id']}' class='btn btn-danger btn-sm'>&#x1F5D1;</a>
                    </td>";
                    echo "<td>
                    <a href='editarform.php?id={$res['id']}&nome={$res['nome']}&email={$res['email']}' class='btn btn-danger btn-sm'>&#9998;</a>
                    </td>";
                }
                echo "</tbody></table>";
            ?>
        </fieldset>
    </div>
 

    <?php if($mensagem): ?>
    <div class="modal fade" id="modalAviso" tabindex="-1" role="dialog" aria-labelledby="modalAvisoLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">  
                <h5 class="modal-title" id="modalAvisoLabel">Aviso</h5>        
                </div>
                <div class="modal-body">
                    <p><?php echo $mensagem;?></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                </div>
            </div>
    </div>

        <!--funcao em java script para pegar a mensagem e exibir automaticamente quando houver-->
    <script>  
            $(document).ready(function() {
                $('#modalAviso').modal('show');
            });
        </script>
    <?php endif;?>
 

</body>
</html>
