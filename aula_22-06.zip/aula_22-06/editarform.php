<?php
session_start();

if (!isset($_SESSION['id']) || !isset($_SESSION['email'])) {
    header('Location: ../login.php');
    exit;
}

$mensagem = isset($_SESSION['mensagem']) ? $_SESSION['mensagem'] : "";
unset($_SESSION['mensagem']);

$nome = isset($_SESSION['nome']) ? $_SESSION['nome'] : "";
include_once('func/conexao.php');
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
    <body>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <title>Document</title>
    </head>

    <header class="bg-dark text-white py-3">
            <div class="container">
                <div class="row">
                    <div class="col">
                    
                        <p class="mb-0">Bem-vindo <?php echo ucwords($nome); ?></p>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                    <a href="func/logout.php">Sair</a>
                    </div>
                </div>
            </div>
        </header>
    <body>
        <div class="container mt-5">
            <form action="func/editar.php" method="post">
                <fieldset class="border p-4">
                    <legend class="w-auto">Editar usuario</legend>
                    <div class="form-group">
                        <label for="nome">Novo nome: </label>
                        <input type="text" class="form-control" name="nome" value="<?php echo ($_GET['nome']);?>" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Novo email: </label>
                        <input type="email" class="form-control" name="email"value="<?php echo ($_GET['email']);?>" required>
                    </div>
                    <div class="form-group">
                        <label for="senha">Nova senha:</label>
                        <input type="password" class="form-control" name="senha" required>
                        
                    </div>
                    <input type="hidden" name="id" value="<?php echo ($_GET['id']);?>">
                    
                    <button type="submit" class="btn btn-primary" name="enviar">EDITAR</button>
                    <a href="index.php" class="btn btn-primary">CANCELAR</a>
                </fieldset>
            </form>
        </div>
        <?php if($mensagem): ?>
    <div class="modal fade" id="modalAviso" tabindex="-1" role="dialog" aria-labelledby="modalAvisoLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">  
                <h5 class="modal-title" id="modalAvisoLabel">Aviso</h5>        
                </div>
                <div class="modal-body">
                    <p><?php echo $mensagem;?></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                </div>
            </div>
    </div>

        <!--funcao em java script para pegar a mensagem e exibir automaticamente quando houver-->
    <script>  
            $(document).ready(function() {
                $('#modalAviso').modal('show');
            });
        </script>
    <?php endif;?>
    </body>
    </html>